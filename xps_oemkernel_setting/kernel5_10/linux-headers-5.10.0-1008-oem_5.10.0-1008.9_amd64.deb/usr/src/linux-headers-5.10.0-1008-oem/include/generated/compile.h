/* This file is auto generated, version 9-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#9-Ubuntu SMP Tue Dec 15 14:22:38 UTC 2020"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-amd64-029"
#define LINUX_COMPILER "gcc (Ubuntu 9.3.0-17ubuntu1~20.04) 9.3.0, GNU ld (GNU Binutils for Ubuntu) 2.34"
